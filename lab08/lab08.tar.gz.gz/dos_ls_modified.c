/* Lab 08
 * CS 301
 * Joel Sommers
 * 3rd Floor
 * McGregory Hall
 * Department of Computer Science
 * Colgate University
 * Hamilton, NY
 * 13346
 * Earth
 * Milky Way Galaxy
 * Authored by: Brian Kinney, Oana Patilea, Nell Lapres, Gaurav Ragtah
 * Actual Comments:
 * We did this is the most hack-ish way possible. This means we just repurposed the dos_ls and dos_cp code.*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <ctype.h>

#include "bootsect.h"
#include "bpb.h"
#include "direntry.h"
#include "fat.h"
#include "dos.h"

// We think this is the same
uint16_t get_dirent(struct direntry *dirent, char *buffer)
{
    uint16_t followclust = 0;
    memset(buffer, 0, MAXFILENAME);

    int i;
    char name[9];
    char extension[4];
    uint16_t file_cluster;
    name[8] = ' ';
    extension[3] = ' ';
    memcpy(name, &(dirent->deName[0]), 8);
    memcpy(extension, dirent->deExtension, 3);
    if (name[0] == SLOT_EMPTY)
    {
	return followclust;
    }

    /* skip over deleted entries */
    if (((uint8_t)name[0]) == SLOT_DELETED)
    {
	return followclust;
    }

    if (((uint8_t)name[0]) == 0x2E)
    {
	// dot entry ("." or "..")
	// skip it
        return followclust;
    }

    /* names are space padded - remove the spaces */
    for (i = 8; i > 0; i--) 
    {
	if (name[i] == ' ') 
	    name[i] = '\0';
	else 
	    break;
    }

    /* remove the spaces from extensions */
    for (i = 3; i > 0; i--) 
    {
	if (extension[i] == ' ') 
	    extension[i] = '\0';
	else 
	    break;
    }

    if ((dirent->deAttributes & ATTR_WIN95LFN) == ATTR_WIN95LFN)
    {
	// ignore any long file name extension entries
	//
	// printf("Win95 long-filename entry seq 0x%0x\n", dirent->deName[0]);
    }
    else if ((dirent->deAttributes & ATTR_DIRECTORY) != 0) 
    {
        // don't deal with hidden directories; MacOS makes these
        // for trash directories and such; just ignore them.
	if ((dirent->deAttributes & ATTR_HIDDEN) != ATTR_HIDDEN)
        {
            strcpy(buffer, name);
            file_cluster = getushort(dirent->deStartCluster);
            followclust = file_cluster;
        }
    }
    else 
    {
        /*
         * a "regular" file entry
         * print attributes, size, starting cluster, etc.
         */
        strcpy(buffer, name);
        if (strlen(extension))  
        {
            strcat(buffer, ".");
            strcat(buffer, extension);
        }
    }

    return followclust;
}
// We didn't touch this
void print_indent(int indent)
{
    int i;
    for (i = 0; i < indent*4; i++)
	printf(" ");
}

// This is completely different.
uint16_t print_dirent(struct direntry *dirent, int indent, uint8_t *image_buf, struct bpb33 *bpb, uint8_t *bytemap)
{
    uint16_t followclust = 0;

    int i;
    char name[9];
    char extension[4];
    uint32_t size;
    uint16_t file_cluster;
    name[8] = ' ';
    extension[3] = ' ';
    memcpy(name, &(dirent->deName[0]), 8);
    memcpy(extension, dirent->deExtension, 3);
    if (name[0] == SLOT_EMPTY)
    {
	return followclust;
    }

    /* skip over deleted entries */
    if (((uint8_t)name[0]) == SLOT_DELETED)
    {
	return followclust;
    }

    if (((uint8_t)name[0]) == 0x2E)
    {
	// dot entry ("." or "..")
	// skip it
        return followclust;
    }

    /* names are space padded - remove the spaces */
    for (i = 8; i > 0; i--) 
    {
	if (name[i] == ' ') 
	    name[i] = '\0';
	else 
	    break;
    }

    /* remove the spaces from extensions */
    for (i = 3; i > 0; i--) 
    {
	if (extension[i] == ' ') 
	    extension[i] = '\0';
	else 
	    break;
    }

    if ((dirent->deAttributes & ATTR_WIN95LFN) == ATTR_WIN95LFN)
    {
	// ignore any long file name extension entries
	//
	// printf("Win95 long-filename entry seq 0x%0x\n", dirent->deName[0]);
    }
    else if ((dirent->deAttributes & ATTR_VOLUME) != 0) 
    {
	printf("Volume: %s\n", name);
    } 
    else if ((dirent->deAttributes & ATTR_DIRECTORY) != 0) 
    {
        // don't deal with hidden directories; MacOS makes these
        // for trash directories and such; just ignore them.
	if ((dirent->deAttributes & ATTR_HIDDEN) != ATTR_HIDDEN)
        {
	    print_indent(indent);
    	    printf("%s/ (directory)\n", name);
		count_clusters(dirent,image_buf,bpb,bytemap);
            file_cluster = getushort(dirent->deStartCluster);
            followclust = file_cluster;
        }
    }
    else 
    {
        /*
         * a "regular" file entry
         * print attributes, size, starting cluster, etc.
	 * Don't do this anymore. Instead, check if the file size is consistent.
         */

	size = getulong(dirent->deFileSize);
	int numclusters = count_clusters(dirent,image_buf,bpb,bytemap);
	int clustersneeded = (size % (bpb->bpbSecPerClust * bpb->bpbBytesPerSec) == 0) ? 
			size / (bpb->bpbSecPerClust * bpb->bpbBytesPerSec) : 
			size / (bpb->bpbSecPerClust * bpb->bpbBytesPerSec) + 1;
	printf("%d clusters found. %d expected.\n", numclusters, clustersneeded);
	if (clustersneeded != numclusters) { 
		printf("Wrong number of clusters! %d found. %d expected.\n", numclusters, clustersneeded);
		if (clustersneeded < numclusters) {
			printf("The file is too small! Freeing excess clusters...\n");
			unsigned int start = getushort(dirent->deStartCluster);
			int n = 1;
			while (n < clustersneeded) {
				start = get_fat_entry(start, image_buf, bpb);
				n++;
			}
			unsigned int current = get_fat_entry(start, image_buf, bpb);
			set_fat_entry(start, CLUST_EOFS & FAT16_MASK, image_buf, bpb);
			unsigned int next;
			while (is_valid_cluster(current,bpb)) {
				next = get_fat_entry(current, image_buf, bpb);
				set_fat_entry(current, CLUST_FREE, image_buf, bpb);
				current = next;
			}
			
		}
		else {
			printf("File does not fit inside the clusters given!\nAdjusting the file size to the new reality...\n");
			unsigned long newsize = numclusters * (bpb->bpbSecPerClust * bpb->bpbBytesPerSec);
			putulong(dirent->deFileSize,newsize);
		}
	}
	print_indent(indent);
    }

    return followclust;
}

// This should be the same
void follow_dir(uint16_t cluster, int indent,
		uint8_t *image_buf, struct bpb33* bpb, uint8_t *bytemap)
{
    while (is_valid_cluster(cluster, bpb))
    {
        struct direntry *dirent = (struct direntry*)cluster_to_addr(cluster, image_buf, bpb);

        int numDirEntries = (bpb->bpbBytesPerSec * bpb->bpbSecPerClust) / sizeof(struct direntry);
        int i = 0;
	for ( ; i < numDirEntries; i++)
	{
            
            uint16_t followclust = print_dirent(dirent, indent, image_buf, bpb, bytemap);
            if (followclust)
                follow_dir(followclust, indent+1, image_buf, bpb, bytemap);
            dirent++;
	}

	cluster = get_fat_entry(cluster, image_buf, bpb);
    }
}

// This now checks for orphans and creates a directory entry for each orphan (up to a max of 1000 orphaned clusters)
void traverse_root(uint8_t *image_buf, struct bpb33* bpb)
{
    uint16_t cluster = 0;
    uint32_t total_clusters = bpb->bpbSectors / bpb->bpbSecPerClust;
    uint8_t bytemap[total_clusters];
    int i = 0;
	int numOrphans = 0;
	char orphanname[13];
    while (i < total_clusters) {
	bytemap[i] = 0;
	i++;
    }
    struct direntry *dirent = (struct direntry*)cluster_to_addr(cluster, image_buf, bpb);
    i = 0;
    for ( ; i < bpb->bpbRootDirEnts; i++)
    {
        uint16_t followclust = print_dirent(dirent, 0, image_buf, bpb, bytemap);
        if (is_valid_cluster(followclust, bpb)) {
            follow_dir(followclust, 1, image_buf, bpb, bytemap);
	}

        dirent++;
    }
    
	for (i = 2; i < total_clusters; i++) {
		if (bytemap[i] == 0) {
			if (get_fat_entry(i,image_buf,bpb) != CLUST_FREE) {
				printf("Orphan Found at %d. Making a Mommy for it.\n",i);
				snprintf(orphanname,13,"found%03d.dat",numOrphans);
				numOrphans++;
				create_dirent1((struct direntry *)root_dir_addr(image_buf,bpb),orphanname,i,(bpb->bpbBytesPerSec)*(bpb->bpbSecPerClust));
			}
		}
	}
    
}


void usage(char *progname)
{
    fprintf(stderr, "usage: %s <imagename>\n", progname);
    exit(1);
}

// This is a function based on a preexisting function (we forget which one) that counts the
// number of clusters in a FAT chain. It also detects bad and inappropriate free clusters
int count_clusters(struct direntry *dirent, uint8_t *image_buf, struct bpb33 *bpb, uint8_t *bytemap)
{
    uint16_t cluster = getushort(dirent->deStartCluster);
    uint32_t bytes_remaining = getulong(dirent->deFileSize);
    uint16_t cluster_size = bpb->bpbBytesPerSec * bpb->bpbSecPerClust;
	int numclusters = 0;
    char buffer[MAXFILENAME];
    get_dirent(dirent, buffer);
	uint16_t next;

    fprintf(stderr, "counting clusters for %s, size %d\n", buffer, bytes_remaining);

    while (is_valid_cluster(cluster, bpb))
    {
        /* map the cluster number to the data location */

        uint32_t nbytes = bytes_remaining > cluster_size ? cluster_size : bytes_remaining;
	numclusters++;
        bytes_remaining -= nbytes;
    	bytemap[cluster] = 1;
        next = get_fat_entry(cluster, image_buf, bpb);
	if (next == (FAT12_MASK & CLUST_BAD) || next == (FAT12_MASK & CLUST_FREE)) {
		printf("Bad or unexpected free cluster found at %d\n",cluster);
		set_fat_entry(cluster, CLUST_EOFS & FAT16_MASK, image_buf, bpb);
		break;
	}
	cluster = next;
    }
	return numclusters;
}
// Main
int main(int argc, char** argv)
{
    uint8_t *image_buf;
    int fd;
    struct bpb33* bpb;
    if (argc != 2)
    {
	usage(argv[0]);
    }

    image_buf = mmap_file(argv[1], &fd);
    bpb = check_bootsector(image_buf);
    traverse_root(image_buf, bpb);

    unmmap_file(image_buf, &fd);

    return 0;
}
