/*
 *  Lab 07
 *  Super Group (Brian, Nell, Oana, Gaurav)
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <strings.h>
#include <string.h>
#include <ucontext.h>

#include "threadsalive.h"


/* stage 1 library functions */

static ucontext_t *head; // Linked list of ready threads
static ucontext_t *tail; // Pointer to the end of the list (for convenience)
static ucontext_t *mainthread;
static tasem_t *semalist; // Linked list of semaphores
#define STACKSIZE 131072

void ta_libinit(void) // Initialize all the stuff needed to make threads using a linked list.
{
	head = NULL;
	mainthread = (ucontext_t *)malloc(sizeof(ucontext_t));
	tail = head;
	getcontext(mainthread); // Store the "main" context here.
    return;
}

void ta_create(void (*func)(void *), void *arg)
{
	ucontext_t *newcontext = (ucontext_t *)malloc(sizeof(ucontext_t));
	unsigned char *stack = (unsigned char *)malloc(STACKSIZE);
	assert(stack);
	getcontext(newcontext);
	newcontext->uc_stack.ss_sp = stack;
	newcontext->uc_stack.ss_size = STACKSIZE;
	push(newcontext);
	makecontext(newcontext, func, 1, arg);
    return;
}

void ta_yield(void)
{
	if (head != NULL) {
		if (head->uc_link == mainthread) { // If this is the case, the current thread is the only ready thread, so do nothing
			return;
		}
		push(pop()); // Pop the head and put it onto the tail.
		swapcontext(tail, head); // Save context into the tail and load the head
	}
	return;
}

int ta_waitall(void)
{
	while (head != NULL) {
		if (head != mainthread) {
			swapcontext(mainthread,head); // Start running threads
		}
		ucontext_t *temp = pop(); // Main only "Wakes up" when a thread finishes (we don't actually know why), so at this point we free its context
		free(temp->uc_stack.ss_sp);
		free(temp);
	}
    return 0;
}

void push(ucontext_t *entry) { // Push onto the tail of the linked list
	if (tail == NULL) {
		tail = entry;
		head = entry;
		tail->uc_link = mainthread;
	}
	else {
		tail->uc_link = entry;
		tail = entry;
		tail->uc_link = mainthread;
	}
	return;
}

ucontext_t *pop() { // Pop from the head of the linked list
	if (head == NULL) {
		return NULL;
	}
	ucontext_t *temp = head;
	head = head->uc_link;
	if (head == NULL) {
		tail = NULL;
	}
	return temp;
}

/* Stage 2 functions */

void ta_sem_init(tasem_t *sema, int value) {
	if (semalist == NULL) { // Initialize in the natural way
		sema->value = value;
		sema->semID = 0;
		sema->next = NULL;
		semalist = sema;
	}
	else {
		tasem_t *temp = semalist;
		int i = 1;
		while (temp->next != NULL) { // Find a place to put the semaphore
			temp = temp->next;
			i++;
		}
		sema->value = value;
		sema->semID = i;
		sema->next = NULL;
		temp->next = sema;
	}
}

void ta_sem_destroy(tasem_t *sema) {
	int ID = sema->semID;
	tasem_t *temp = semalist;
	tasem_t *prev;
	while (temp != NULL && temp->semID != ID) { // These are not the semaphores you are looking for
		prev = temp;	
		temp = temp->next;
	} // Now temp == sema. Prev will help us remove sema from the list.
	if (temp == NULL) {
		fprintf(stderr,"Error: semaphore not found.\n");
	}
	else if (temp->semID == ID) {
		if (temp == semalist) { // Delete when temp is the head of the list
			semalist = semalist->next;
		}
		else { // Delete when temp is not the head of the list
			prev->next = temp->next;
		}
		ucontext_t *wait = temp->waitlist;
		ucontext_t *con;
		while (wait != NULL) { // Kill the processes waiting on this semaphore
			con = wait;
			wait = wait->uc_link;
			free(con->uc_stack.ss_sp);
			free(con);
		}
	}
}

void ta_sem_post(tasem_t *sema) {
	sema->value += 1; // Increment the semaphore
	if (sema->waitlist != NULL) { // If there is anyone waiting, we can ready them now.
		ucontext_t *temp = sema->waitlist;
		sema->waitlist = sema->waitlist->uc_link;
		push(temp);
	}
	return;
}

void ta_sem_wait(tasem_t *sema) {
	if (sema->value <= 0) { // Put me on the wait list
		ucontext_t *temp = pop();
		temp->uc_link = NULL;
		ucontext_t *wait;
		if (sema->waitlist == NULL) {
			sema->waitlist = temp; // I'm next!
		}
		else {
			wait = sema->waitlist;
			while (wait->uc_link != NULL) {
				wait = wait->uc_link;
			}
			wait->uc_link = temp; // I'm at the end of the list :(
		}
		swapcontext(temp,head);
	}
	else {
		sema->value -= 1; // I can access the shared memory!
	}
	return;
}

// We just used semaphore to implement the lock.

void ta_lock_init(talock_t *lock) {
	ta_sem_init(lock,1);
}

void ta_lock_destroy(talock_t *lock) {
	ta_sem_destroy(lock);
}

void ta_unlock(talock_t *lock) {
	ta_sem_post(lock);
}

void ta_lock(talock_t *lock) {
	ta_sem_wait(lock);
}