/*
 *  Lab 07
 *  Super Group (Brian, Nell, Oana, Gaurav)
 */

#ifndef __THREADSALIVE_H__
#define __THREADSALIVE_H__
#include <ucontext.h>

void ta_libinit(void);
void ta_create(void (*)(void *), void *);
void ta_yield(void);
int ta_waitall(void);
void push(ucontext_t *);
ucontext_t *pop(void);
void threadcleanup(void);
void gotonext(void);

struct tasem {
	int value;
	int semID;
	ucontext_t *waitlist;
	struct tasem *next;
};

typedef struct tasem tasem_t;
typedef struct tasem talock_t;

void ta_sem_init(tasem_t *, int);
void ta_sem_destroy(tasem_t *);
void ta_sem_post(tasem_t *);
void ta_sem_wait(tasem_t *);
void ta_lock_init(talock_t *);
void ta_lock_destroy(talock_t *);
void ta_lock(talock_t *);
void ta_unlock(talock_t *);

#endif /* __THREADSALIVE_H__ */
